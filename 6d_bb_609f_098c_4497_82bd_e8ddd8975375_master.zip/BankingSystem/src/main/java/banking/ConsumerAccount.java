package banking;

public class ConsumerAccount  {
	public ConsumerAccount(Person person, Long accountNumber, int pin, double currentBalance) {
		// complete the function
	}
}
